# frozen_string_literal: true
module Gem::Resolver::Molinillo
  # The version of Gem::Resolver::Molinillo.
  VERSION = '0.5.7'.freeze
end
